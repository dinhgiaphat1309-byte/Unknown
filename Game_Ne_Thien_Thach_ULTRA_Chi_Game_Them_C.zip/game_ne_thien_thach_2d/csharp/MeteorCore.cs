// Lõi logic C# có thể tích hợp vào Unity/.NET
using System;
public struct Circle { public float X,Y,R; public Circle(float x,float y,float r){X=x;Y=y;R=r;} }
public static class MeteorCore {
 public static void Move(ref Circle p,float dx,float dy,float dt,float width,float height,float speed=680f){
  float n=MathF.Sqrt(dx*dx+dy*dy);if(n>0){dx/=n;dy/=n;}
  p.X=Math.Clamp(p.X+dx*speed*dt,p.R,width-p.R);p.Y=Math.Clamp(p.Y+dy*speed*dt,p.R,height-p.R);
 }
 public static bool Collides(Circle a,Circle b){float dx=a.X-b.X,dy=a.Y-b.Y,r=a.R+b.R;return dx*dx+dy*dy<=r*r;}
}
