-- Lõi logic Lua dùng tham khảo với LÖVE2D
local M = { player = {x=400, y=300, r=9, speed=680}, rocks={} }
function M.movePlayer(dx,dy,dt,width,height)
  local p=M.player; local n=math.sqrt(dx*dx+dy*dy)
  if n>0 then dx,dy=dx/n,dy/n end
  p.x=math.max(p.r,math.min(width-p.r,p.x+dx*p.speed*dt))
  p.y=math.max(p.r,math.min(height-p.r,p.y+dy*p.speed*dt))
end
function M.collides(a,b)
  local dx,dy=a.x-b.x,a.y-b.y; local r=a.r+b.r
  return dx*dx+dy*dy<=r*r
end
return M
