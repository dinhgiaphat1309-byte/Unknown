NÉ THIÊN THẠCH 2D — ULTRA ∞

CHẠY TRÊN NETLIFY
1. Giải nén ZIP.
2. Mở thư mục game_ne_thien_thach_2d_upgrade (thư mục có index.html ngay bên trong).
3. Kéo thư mục đó vào https://app.netlify.com/drop hoặc tải nội dung thư mục lên site Netlify.
4. Mở link .netlify.app mà Netlify cấp.

TÍNH NĂNG MỚI
- Level vô hạn: cứ 15 giây tăng 1 level, độ khó và tốc độ thiên thạch tăng dần.
- Nút LƯỚT: tăng tốc tức thời, có thời gian hồi chiêu; Space/Shift trên máy tính.
- Vật phẩm KHIÊN: nhặt vòng xanh để có khiên 7 giây.
- Điều khiển chạm-kéo trên mobile, WASD/phím mũi tên trên máy tính.
- Tự lưu kỷ lục trên trình duyệt, hiệu ứng nhẹ và giới hạn thiên thạch để giảm lag.

CÁC FILE MÃ NGUỒN
- index.html, style.css, game.js: bản chạy trực tiếp trên web.
- lua/meteor.lua, cpp/meteor.cpp, c/meteor.c, csharp/MeteorCore.cs: ví dụ logic thiên thạch riêng cho các ngôn ngữ đó.

LƯU Ý: ZIP có thể được tải lên Netlify sau khi giải nén. Đảm bảo index.html nằm ở thư mục gốc được publish.


NÂNG CẤP THIÊN THẠCH VÔ HÌNH:
- Chỉ khi đạt từ 50 điểm trở lên, thiên thạch vô hình mới bắt đầu xuất hiện; trước đó tất cả thiên thạch đều nhìn thấy được.
- Sau mốc 50 điểm, tỷ lệ thiên thạch vô hình tăng dần theo Level, tối đa 22%.


CẬP NHẬT TOÀN MÀN HÌNH: Nhấn nút TOÀN MÀN HÌNH trong game để mở rộng khu vực chơi phủ kín màn hình. Nhấn lại nút hoặc thoát fullscreen của trình duyệt để trở về.


CẬP NHẬT HÌNH NỀN: Khu vực chơi sử dụng ảnh nền từ URL do người chơi cung cấp. Cần có kết nối Internet để tải ảnh.


CẬP NHẬT XUYÊN THIÊN THẠCH 50%:
- Khi va chạm thiên thạch mà không có khiên/lướt bảo vệ, có 50% cơ hội xuyên qua và tiếp tục chơi; 50% còn lại là Game Over.
- Sau lần xuyên thành công có khoảng nghỉ 0,85 giây để tránh tung xúc xắc liên tục khi còn chồng lên vật thể.


BẢN CHỈ CÒN GAME THIÊN THẠCH: Đã xóa toàn bộ giao diện và mã camera/đoán tuổi.
- Game tự mở màn hình bắt đầu; bấm BẮT ĐẦU CHƠI để chơi.
- Có thêm c/meteor.c làm ví dụ mã nguồn C cho logic va chạm và xác suất xuyên thiên thạch 50%.
