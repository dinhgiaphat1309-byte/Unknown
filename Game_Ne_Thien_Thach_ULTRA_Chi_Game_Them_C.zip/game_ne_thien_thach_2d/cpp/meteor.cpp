// Lõi logic C++17: di chuyển và kiểm tra va chạm
#include <algorithm>
#include <cmath>
struct Circle { float x, y, r; };
void movePlayer(Circle& p,float dx,float dy,float dt,float width,float height,float speed=680.f){
 float n=std::sqrt(dx*dx+dy*dy); if(n>0.f){dx/=n;dy/=n;}
 p.x=std::clamp(p.x+dx*speed*dt,p.r,width-p.r);
 p.y=std::clamp(p.y+dy*speed*dt,p.r,height-p.r);
}
bool collides(const Circle&a,const Circle&b){float dx=a.x-b.x,dy=a.y-b.y,r=a.r+b.r;return dx*dx+dy*dy<=r*r;}
