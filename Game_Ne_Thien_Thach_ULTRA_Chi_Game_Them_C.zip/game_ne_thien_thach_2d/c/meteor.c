/* Ví dụ logic C cho game Né Thiên Thạch ULTRA.
 * Biên dịch thử: cc meteor.c -o meteor (cần thêm -DTEST để chạy demo).
 * Trò chơi chạy trên web bằng HTML/CSS/JavaScript; file C này là mã nguồn tham khảo.
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* Trả về 1 nếu người chơi xuyên qua được, 0 nếu va chạm gây Game Over.
   Mỗi lần va chạm không có khiên có xác suất 50/50. */
int meteor_phase_success(void) {
    return rand() % 2;
}

/* Trả về 1 nếu vẫn sống sau va chạm; có khiên thì luôn sống. */
int handle_meteor_collision(int has_shield) {
    if (has_shield) return 1;
    return meteor_phase_success();
}

#ifdef TEST
int main(void) {
    int i, survived = 0;
    srand((unsigned int)time(NULL));
    for (i = 0; i < 10; ++i) {
        int ok = handle_meteor_collision(0);
        printf("Lan va cham %d: %s\n", i + 1,
               ok ? "XUYEN THANH CONG" : "GAME OVER");
        survived += ok;
    }
    printf("Xuyen thanh cong: %d/10 (xac suat ky vong 50%%)\n", survived);
    return 0;
}
#endif
